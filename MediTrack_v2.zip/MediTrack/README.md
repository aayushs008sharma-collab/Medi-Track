# MediTrack — Smart Hospital Management System v2.0

A production-ready hospital queue management backend built with Node.js + Express.

---

## What's New in v2.0

| Area | v1.0 | v2.0 |
|---|---|---|
| Auth | Single hardcoded password | JWT tokens, role-based access (Admin/Doctor/Receptionist/Pharmacist) |
| Validation | Manual `if (!name)` checks | Joi schema validation on every endpoint |
| Queue ETA | Static random number | Real algorithm: dept consult times × queue depth × priority |
| DB writes | Synchronous, race-prone | Queued async writes with atomic rename (no corruption) |
| Error handling | None | Global error handler, structured JSON errors |
| Security | None | Helmet headers, CORS config, rate limiting (500 req/15min, 20 login/15min) |
| Logging | `console.log` | Winston — console + rotating log files |
| API design | Ad-hoc POST routes | RESTful (GET/POST/PATCH/DELETE) with legacy shims |
| Backward compat | — | All old frontend calls still work unchanged |

---

## Project Structure

```
MedQueue_Enhanced/
├── server.js                  # Entry point — middleware, routes, startup
├── package.json
├── data/
│   ├── db.json                # Live database (JSON file)
│   └── default-db.json        # Factory reset snapshot
├── logs/                      # Auto-created: combined.log, error.log
├── public/                    # Frontend (unchanged from v1)
└── src/
    ├── middleware/
    │   ├── auth.js            # JWT verify, requireAuth, requireRole
    │   ├── validate.js        # Joi schemas + validate() middleware
    │   └── errorHandler.js    # Global error + 404 handlers
    ├── routes/
    │   ├── auth.js            # POST /api/login, /api/refresh, GET /api/me
    │   ├── patients.js        # /api/patients, /api/queue/*
    │   ├── ambulances.js      # /api/ambulances, /api/ambulances/dispatch
    │   ├── medicines.js       # /api/medicines
    │   ├── doctors.js         # /api/doctors
    │   ├── analytics.js       # /api/analytics
    │   └── notifications.js   # /api/notifications
    ├── services/
    │   ├── db.js              # Cached read, queued atomic write, reset
    │   ├── queue.js           # ETA calc, priority sort, token gen, metrics
    │   ├── fleet.js           # Ambulance ETA with traffic + siren factors
    │   └── notifications.js   # Create, timestamp-refresh, trim
    └── utils/
        └── logger.js          # Winston logger
```

---

## Installation

```bash
npm install
npm run dev     # development (nodemon)
npm start       # production
```

---

## Authentication

All `/api/*` routes (except `/api/health` and `/api/login`) require a Bearer token.

**Login:**
```http
POST /api/login
Content-Type: application/json

{ "password": "12345678", "role": "Receptionist" }
```

**Response:**
```json
{ "success": true, "token": "eyJ...", "role": "Receptionist", "expiresIn": "8h" }
```

**Default Passwords:**

| Role | Password |
|---|---|
| Receptionist | `12345678` |
| Doctor | `doctor123` |
| Pharmacist | `pharm123` |
| Admin | `admin1234` |

Override via environment variables: `ADMIN_PASSWORD`, `DOCTOR_PASSWORD`, `RECEP_PASSWORD`, `PHARM_PASSWORD`.

**Use the token:**
```http
Authorization: Bearer eyJ...
```

---

## API Reference

### Health
```
GET /api/health           — no auth — uptime, queue snapshot
```

### Auth
```
POST  /api/login          — get JWT
POST  /api/refresh        — renew JWT
GET   /api/me             — current user
```

### Patients & Queue
```
GET    /api/patients                   — list (filter: ?status=Waiting&dept=Cardiology)
GET    /api/patients/:token            — single patient + live ETA
POST   /api/patients                   — register patient
PATCH  /api/patients/:token            — update status
DELETE /api/patients/:token            — remove (Admin only)

POST   /api/queue/call-next            — call next patient (?dept optional)
GET    /api/queue/eta/:token           — ETA for a token
GET    /api/queue/metrics              — queue KPIs
```

### Ambulances
```
GET   /api/ambulances                  — fleet status
POST  /api/ambulances/dispatch         — dispatch with real ETA calculation
PATCH /api/ambulances/:unit            — update status (return, maintenance)
```

### Medicines
```
GET    /api/medicines                  — list (filter: ?status=Low+Stock)
GET    /api/medicines/:id              — single medicine
POST   /api/medicines                  — add (Admin/Pharmacist)
PATCH  /api/medicines/:id              — update status
DELETE /api/medicines/:id              — remove (Admin/Pharmacist)
```

### Doctors
```
GET   /api/doctors                     — list with patient counts
GET   /api/doctors/:name               — doctor + assigned patients
PATCH /api/doctors/:name               — update availability (Admin/Doctor)
```

### Analytics
```
GET /api/analytics                     — full analytics snapshot
GET /api/analytics/summary             — dashboard KPIs
GET /api/analytics/dept                — per-department breakdown
```

### Notifications
```
GET    /api/notifications              — list with refreshed timestamps
POST   /api/notifications/read         — mark all read
DELETE /api/notifications/:id          — delete one
DELETE /api/notifications              — clear all (Admin)
```

### System
```
GET  /api/all-data                     — legacy all-in-one (backward compat)
POST /api/reset                        — reset DB to defaults
```

---

## ETA Algorithm

Wait time for a patient is calculated as:

```
eta = (patients_ahead_in_dept × avg_dept_consult_time)
    + (serving_in_dept > 0 ? consult_time × 0.5 : 0)
    + (global_queue_pressure × 0.3)
```

Average consultation times by department (minutes):
- Emergency: 10 · Cardiology: 20 · General Medicine: 15 · Pediatrics: 15
- Orthopedics: 18 · Neurology: 22 · Psychiatry: 25 · Oncology: 25 · others: 12–18

Emergency patients skip to the front and get a 2-min minimum ETA.

---

## Ambulance ETA Algorithm

```
effective_speed = (BASE_SPEED / traffic_factor) × siren_discount
eta_minutes     = ceil(distance_km / effective_speed × 60)
```

- Base speed: 40 km/h
- Traffic factor: 1.0 (night) → 1.8 (morning rush, 8 AM)
- Siren discount: Emergency/Cardiac → 0.60 (40% faster)

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `5000` | Server port |
| `JWT_SECRET` | `medqueue_dev_secret_...` | **Change in production** |
| `NODE_ENV` | `development` | Controls stack traces in errors |
| `LOG_LEVEL` | `info` | Winston log level |
| `CORS_ORIGIN` | `*` | Restrict in production |
| `ADMIN_PASSWORD` | `admin1234` | Admin login password |
| `DOCTOR_PASSWORD` | `doctor123` | Doctor login password |
| `RECEP_PASSWORD` | `12345678` | Receptionist login password |
| `PHARM_PASSWORD` | `pharm123` | Pharmacist login password |

---

## Legacy Compatibility

All original frontend API calls still work unchanged:
- `POST /api/add-patient` → internally routed to `POST /api/patients`
- `POST /api/update-patient` → `PATCH /api/patients/:token`
- `POST /api/call-next` → `POST /api/queue/call-next`
- `POST /api/dispatch-ambulance` → `POST /api/ambulances/dispatch`
- `POST /api/update-medicine` → `PATCH /api/medicines/:id`
- `POST /api/read-notifications` → `POST /api/notifications/read`
- `GET  /api/all-data` → returns same shape as v1
