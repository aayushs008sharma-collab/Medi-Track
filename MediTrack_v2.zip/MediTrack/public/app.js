/**
 * MediTrack Frontend — app.js
 * JWT-aware, role-based, fully wired to the v2 backend API.
 */

"use strict";

// ── State ───────────────────────────────────────────────────────────────────
let jwtToken   = localStorage.getItem("mt_token") || "";
let userRole   = localStorage.getItem("mt_role")  || "Receptionist";
let patients   = [], doctors = [], medicines = [], fleet = [], notifications = [];
let analytics  = { hours: [], flow: [], weekly: [] };
let notifyFilter = "All";

// ── API helper ──────────────────────────────────────────────────────────────
async function api(url, options = {}) {
  const headers = { "Content-Type": "application/json" };
  if (jwtToken) headers["Authorization"] = "Bearer " + jwtToken;

  const res = await fetch(url, { headers, ...options });

  // Token expired — force re-login
  if (res.status === 401) {
    jwtToken = "";
    localStorage.removeItem("mt_token");
    showLoginScreen();
    throw new Error("Session expired. Please sign in again.");
  }

  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
}

// ── Auth ────────────────────────────────────────────────────────────────────
function setRole(btn, r) {
  userRole = r;
  document.querySelectorAll(".role").forEach(x => x.classList.remove("active"));
  btn.classList.add("active");
}

function togglePassword() {
  const p = document.getElementById("loginPass");
  p.type = p.type === "password" ? "text" : "password";
}

async function loginApp() {
  const password = document.getElementById("loginPass").value.trim();
  if (!password) { toast("Missing password", "Please enter your password"); return; }
  try {
    const data = await api("/api/login", {
      method: "POST",
      body: JSON.stringify({ role: userRole, password })
    });
    jwtToken  = data.token;
    userRole  = data.role;
    localStorage.setItem("mt_token", jwtToken);
    localStorage.setItem("mt_role",  userRole);
    showAppScreen();
    await loadData();
    toast("Welcome to MediTrack ✓", `Signed in as ${userRole}`);
  } catch (e) {
    toast("Access denied", e.message || "Incorrect password");
    document.getElementById("loginPass").value = "";
  }
}

function showLoginScreen() {
  document.getElementById("app").classList.add("hidden");
  document.getElementById("login").classList.remove("hidden");
}

function showAppScreen() {
  document.getElementById("login").classList.add("hidden");
  document.getElementById("app").classList.remove("hidden");
  // Set avatar + user info
  const initials = userRole.slice(0, 2).toUpperCase();
  document.getElementById("userAvatar").textContent = initials;
  document.getElementById("userRole").textContent   = userRole;
  const names = { Admin: "Admin User", Doctor: "Dr. Raj Mehra", Receptionist: "Reception Desk", Pharmacist: "Pharmacy Desk" };
  document.getElementById("userName").textContent = names[userRole] || "MediTrack User";
}

function logoutApp() {
  jwtToken = "";
  localStorage.removeItem("mt_token");
  localStorage.removeItem("mt_role");
  showLoginScreen();
}

// Auto-login if valid token exists
(async function autoLogin() {
  if (!jwtToken) return;
  try {
    await api("/api/me");
    showAppScreen();
    await loadData();
  } catch (_) {
    jwtToken = "";
    localStorage.removeItem("mt_token");
  }
})();

// ── Data loading ────────────────────────────────────────────────────────────
async function loadData() {
  try {
    const data = await api("/api/all-data");
    patients      = data.patients      || [];
    doctors       = data.doctors       || [];
    medicines     = data.medicines     || [];
    fleet         = data.fleet         || [];
    notifications = data.notifications || [];
    analytics     = data.analytics     || { hours: [], flow: [], weekly: [] };
    renderAll();
  } catch (e) {
    toast("Load error", e.message);
  }
}

// ── Navigation ──────────────────────────────────────────────────────────────
function showPage(id, btn) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  document.querySelectorAll("#nav button").forEach(b => b.classList.remove("active"));
  if (btn) btn.classList.add("active");
  renderAll();
}

// ── Render all ──────────────────────────────────────────────────────────────
function renderAll() {
  renderDashboard();
  renderPatients();
  renderDoctors();
  renderFleet();
  renderMedicine();
  renderNotifications();
  renderCharts();
  renderAnalyticsStats();
}

// ── Dashboard ───────────────────────────────────────────────────────────────
function renderDashboard() {
  const el = id => document.getElementById(id);
  if (!el("totalPatients")) return;

  const waiting   = patients.filter(p => p.status === "Waiting").length;
  const emergency = patients.filter(p => p.priority === "Emergency" && p.status !== "Done").length;
  const activeDrs = doctors.filter(d => d.status === "Available" || d.status === "Busy").length;
  const waitingPts = patients.filter(p => p.status === "Waiting");
  const avgWait   = waitingPts.length
    ? Math.round(waitingPts.reduce((s, p) => s + (p.wait || 0), 0) / waitingPts.length)
    : 0;

  el("totalPatients").textContent  = patients.length;
  el("waitingPatients").textContent = waiting;
  el("doctorsActive").textContent  = activeDrs;
  el("emergencyCount").textContent  = emergency;
  el("avgWaitLabel").textContent    = `Avg ${avgWait} min`;

  // Activity feed from notifications
  const feed = el("activityFeed");
  if (feed) {
    const colors = ["var(--red)", "var(--blue)", "var(--amber)", "var(--green)", "var(--purple)"];
    feed.innerHTML = notifications.slice(0, 4).map((n, i) =>
      `<div class="act"><span class="dot" style="background:${colors[i % colors.length]}"></span>
       <div><b>${n.title}</b><p class="muted">${n.body} <small>· ${n.time}</small></p></div></div>`
    ).join("") || "<div class='empty'>No recent activity</div>";
  }

  // Department overview
  const depts = el("departments");
  if (depts) {
    const deptMap = {};
    patients.filter(p => p.status !== "Done").forEach(p => {
      deptMap[p.dept] = (deptMap[p.dept] || 0) + 1;
    });
    const deptList = Object.entries(deptMap).sort((a, b) => b[1] - a[1]).slice(0, 5);
    const maxVal   = Math.max(...deptList.map(d => d[1]), 1);
    depts.innerHTML = deptList.map(([name, count]) =>
      `<div class="prog-row">
        <div style="display:flex;justify-content:space-between">
          <b>${name}</b><span class="muted">${count} patient${count !== 1 ? "s" : ""}</span>
        </div>
        <div class="prog-line"><div style="width:${(count/maxVal*100).toFixed(0)}%"></div></div>
      </div>`
    ).join("") || "<p class='muted' style='margin-top:12px'>No active patients</p>";
  }
}

// ── Patients ────────────────────────────────────────────────────────────────
function renderPatients() {
  const el = document.getElementById("patientCards");
  if (!el) return;
  if (!patients.length) { el.innerHTML = "<div class='empty'>No patients registered yet</div>"; return; }

  const sorted = [...patients].sort((a, b) => {
    const w = { Emergency: 0, Urgent: 1, Normal: 2 };
    const pw = (w[a.priority] ?? 2) - (w[b.priority] ?? 2);
    if (pw) return pw;
    return a.status === "Waiting" ? -1 : 1;
  });

  el.innerHTML = sorted.map(p => {
    const priorityClass = p.priority === "Emergency" ? "red" : p.priority === "Urgent" ? "amber" : "blue";
    const statusClass   = p.status === "Serving" ? "green" : p.status === "Done" ? "purple" : "blue";
    const etaLabel      = p.status === "Serving" ? "Serving now" : p.status === "Done" ? "Done" : `~${p.wait ?? "—"} min`;
    return `<div class="patient-card ${p.priority === "Emergency" ? "emergency" : ""}">
      <div class="pc-top">
        <div><div class="token">${p.token}</div><h3>${p.name}</h3></div>
        <span class="pill ${priorityClass}">${p.priority}</span>
      </div>
      <p class="muted">${p.age} yrs • ${p.gender} • ${p.dept}</p>
      <div class="meta">
        <span class="pill ${statusClass}">${p.status}</span>
        <span class="eta-badge">⏱ ${etaLabel}</span>
        <span class="pill blue">${p.doctor}</span>
      </div>
      <p style="font-size:13px"><b>Symptoms:</b> ${p.symptoms}</p>
      <div class="actions">
        ${p.status === "Waiting"  ? `<button class="btn btn-primary"  onclick="startPatient('${p.token}')">▶ Start</button>` : ""}
        ${p.status === "Serving"  ? `<button class="btn btn-soft"     onclick="donePatient('${p.token}')">✓ Done</button>` : ""}
        ${p.status !== "Done"     ? `<button class="btn btn-danger"   onclick="noShowPatient('${p.token}')">✕ No Show</button>` : ""}
        <button class="btn btn-ghost" onclick="toast('${p.token}','${p.name} · ${p.dept} · ${p.doctor}')">ℹ Info</button>
      </div>
    </div>`;
  }).join("");
}

async function addPatient() {
  const name = document.getElementById("pName").value.trim();
  const age  = document.getElementById("pAge").value;
  if (!name || !age) { toast("Missing info", "Enter name and age"); return; }
  try {
    const data = await api("/api/add-patient", {
      method: "POST",
      body: JSON.stringify({
        name, age,
        gender:   document.getElementById("pGender").value,
        dept:     document.getElementById("pDept").value,
        priority: document.getElementById("pPriority").value,
        symptoms: document.getElementById("pSymptoms").value.trim() || "General consultation"
      })
    });
    document.getElementById("pName").value = document.getElementById("pAge").value = document.getElementById("pSymptoms").value = "";
    toast(`Token: ${data.patient.token} ✓`, `${name} added — ETA ~${data.patient.wait} min`);
    await loadData();
  } catch (e) { toast("Error", e.message); }
}

async function startPatient(token) {
  try {
    await api("/api/update-patient", { method: "POST", body: JSON.stringify({ token, status: "Serving" }) });
    toast("Now serving", `${token} moved to consultation`);
    await loadData();
  } catch (e) { toast("Error", e.message); }
}

async function donePatient(token) {
  try {
    await api("/api/update-patient", { method: "POST", body: JSON.stringify({ token, status: "Done" }) });
    toast("Completed ✓", `${token} marked done`);
    await loadData();
  } catch (e) { toast("Error", e.message); }
}

async function noShowPatient(token) {
  try {
    await api("/api/update-patient", { method: "POST", body: JSON.stringify({ token, status: "No Show" }) });
    toast("No show", `${token} removed from queue`);
    await loadData();
  } catch (e) { toast("Error", e.message); }
}

async function callNext() {
  try {
    const data = await api("/api/call-next", { method: "POST" });
    toast(`Now calling ${data.patient.token}`, `${data.patient.name} — ${data.patient.dept}`);
    await loadData();
  } catch (e) { toast("Queue empty", "No waiting patients"); }
}

// ── Doctors ─────────────────────────────────────────────────────────────────
function renderDoctors() {
  const el = document.getElementById("doctorList");
  if (!el) return;
  el.innerHTML = doctors.map(d => {
    const statusClass = d.status === "Available" ? "green" : d.status === "Busy" ? "red" : "amber";
    const serving = patients.find(p => p.doctor === d.name && p.status === "Serving");
    return `<div class="doctor-card">
      <div>
        <h3>${d.name}</h3>
        <p class="muted">${d.department} • ${d.room}${serving ? ` • Serving: ${serving.name}` : ""}</p>
      </div>
      <span class="pill ${statusClass}">${d.status}</span>
    </div>`;
  }).join("") || "<div class='empty'>No doctors found</div>";
}

// ── Fleet / Ambulance ───────────────────────────────────────────────────────
function renderFleet() {
  const el = document.getElementById("fleetList");
  if (!el) return;

  const avail   = fleet.filter(a => a.status === "Available").length;
  const enRoute = fleet.filter(a => a.status === "En Route").length;
  const etaVals = fleet.filter(a => a.etaMinutes).map(a => a.etaMinutes);
  const avgEta  = etaVals.length ? Math.round(etaVals.reduce((s, v) => s + v, 0) / etaVals.length) : 0;

  const setEl = (id, val) => { const e = document.getElementById(id); if (e) e.textContent = val; };
  setEl("fleetAvail",   avail);
  setEl("fleetEnRoute", enRoute);
  setEl("avgETA",       avgEta ? avgEta + "m" : "—");

  el.innerHTML = fleet.map(f => {
    const statusClass = f.status === "Available" ? "green" : f.status === "En Route" ? "red" : "amber";
    return `<div class="fleet-card">
      <div>
        <h3>${f.unit} <small style="font-weight:400;color:var(--muted)">· ${f.driver}</small></h3>
        <p class="muted">
          ${f.distance} away · ETA ${f.eta}
          ${f.location ? " · 📍 " + f.location : ""}
          ${f.caseType ? " · " + f.caseType : ""}
        </p>
      </div>
      <span class="pill ${statusClass}">${f.status}</span>
    </div>`;
  }).join("") || "<div class='empty'>No fleet data</div>";

  // Update map pins
  const map = document.getElementById("map");
  if (map) {
    map.querySelectorAll(".amb-dot").forEach(x => x.remove());
    const positions = [[22,33],[67,28],[78,70],[35,74]];
    fleet.forEach((f, i) => {
      const pos = positions[i] || [50, 50];
      const el2 = document.createElement("div");
      el2.className = "map-pin amb-dot";
      el2.style.left = pos[0] + "%";
      el2.style.top  = pos[1] + "%";
      el2.innerHTML = `<div class="pin-dot" style="background:${f.status === "En Route" ? "var(--red)" : "var(--blue)"}"></div><span>${f.unit}</span>`;
      map.appendChild(el2);
    });
  }
}

function showDispatchForm() {
  const f = document.getElementById("dispatchForm");
  f.style.display = f.style.display === "none" ? "block" : "none";
}

async function dispatchAmbulance() {
  const location = document.getElementById("dLocation").value.trim();
  const caseType = document.getElementById("dCaseType").value;
  const unit     = document.getElementById("dUnit").value;
  if (!location) { toast("Location required", "Enter an emergency location"); return; }
  try {
    const data = await api("/api/dispatch-ambulance", {
      method: "POST",
      body: JSON.stringify({ location, caseType, unit: unit || undefined })
    });
    document.getElementById("dispatchForm").style.display = "none";
    document.getElementById("dLocation").value = "";
    toast(`${data.ambulance.unit} dispatched 🚑`, `${caseType} at ${location} · ETA ${data.ambulance.eta}`);
    await loadData();
  } catch (e) { toast("Dispatch failed", e.message); }
}

// ── Medicine ────────────────────────────────────────────────────────────────
function renderMedicine() {
  const el = document.getElementById("medicineList");
  if (!el) return;
  el.innerHTML = medicines.map(m => {
    const sc = m.status === "Low Stock" || m.status === "Missed" || m.status === "Out of Stock" ? "red"
             : m.status === "Completed" ? "green" : "blue";
    return `<div class="medicine-card">
      <div>
        <h3>${m.name}</h3>
        <p class="muted">${m.patient || "Stock"} · ${m.time} · Stock: ${m.stock}</p>
      </div>
      <div style="display:flex;gap:10px;align-items:center">
        <span class="pill ${sc}">${m.status}</span>
        ${m.status !== "Completed" ? `<button class="btn btn-soft" onclick="updateMedicine(${m.id})">✓ Complete</button>` : ""}
      </div>
    </div>`;
  }).join("") || "<div class='empty'>No medicines listed</div>";
}

async function updateMedicine(id) {
  try {
    await api("/api/update-medicine", { method: "POST", body: JSON.stringify({ id, status: "Completed" }) });
    toast("Updated ✓", "Medicine marked completed");
    await loadData();
  } catch (e) { toast("Error", e.message); }
}

function orderRefills() { toast("Refill requested 📦", "Low-stock medicines added to purchase list"); }

// ── Analytics ───────────────────────────────────────────────────────────────
function renderAnalyticsStats() {
  const setEl = (id, val) => { const e = document.getElementById(id); if (e) e.textContent = val; };
  const waitingPts = patients.filter(p => p.status === "Waiting");
  const avgWait = waitingPts.length
    ? Math.round(waitingPts.reduce((s, p) => s + (p.wait || 0), 0) / waitingPts.length)
    : 0;
  setEl("analyticsAvgWait", avgWait + "m");
  setEl("analyticsTotal",   patients.length);
  setEl("analyticsEmerg",   patients.filter(p => p.priority === "Emergency").length);
  setEl("analyticsServing", patients.filter(p => p.status === "Serving").length);
}

// ── Charts ──────────────────────────────────────────────────────────────────
function renderCharts() {
  const hours = analytics.hours.length ? analytics.hours
    : ["6AM","7AM","8AM","9AM","10AM","11AM","12PM","1PM","2PM","3PM","4PM","5PM"];
  const vals  = analytics.flow.length  ? analytics.flow
    : [3,5,8,12,14,11,9,10,12,9,7,6];

  function renderChart(elId, labels, values) {
    const el = document.getElementById(elId);
    if (!el) return;
    const maxVal = Math.max(...values, 1);
    el.innerHTML = labels.map((h, i) =>
      `<div class="bar" style="height:${Math.round((values[i] / maxVal) * 180)}px">
         <small>${h}</small>
       </div>`
    ).join("");
  }

  renderChart("flowChart",      hours, vals);
  renderChart("analyticsChart", hours, vals);
}

// ── Notifications ───────────────────────────────────────────────────────────
function renderNotifications(type) {
  if (type) notifyFilter = type;
  const el = document.getElementById("notifyList");
  if (!el) return;

  const list = notifyFilter === "All" ? notifications
    : notifications.filter(n => n.type === notifyFilter);

  el.innerHTML = list.map(n => {
    const tc = n.type === "Emergency" ? "red" : n.type === "AI" ? "purple" : n.type === "Fleet" ? "blue" : n.type === "Medicine" ? "amber" : "blue";
    return `<div class="notify-card ${n.unread ? "unread" : ""}">
      <div>
        <h3>${n.icon || ""} ${n.title}</h3>
        <p class="muted">${n.body}</p>
        <small class="muted">${n.time}</small>
      </div>
      <span class="pill ${tc}">${n.type}</span>
    </div>`;
  }).join("") || "<div class='empty'>No notifications</div>";

  const unread = notifications.filter(n => n.unread).length;
  const bc = document.getElementById("bellCount");
  if (bc) bc.textContent = unread;
  const ut = document.getElementById("unreadText");
  if (ut) ut.textContent = `${unread} unread`;
}

function filterNotify(t, btn) {
  document.querySelectorAll("#tabs button").forEach(b => b.classList.remove("active"));
  if (btn) btn.classList.add("active");
  renderNotifications(t);
}

async function markAllRead() {
  try {
    await api("/api/read-notifications", { method: "POST" });
    toast("All read ✓", "Notifications cleared");
    await loadData();
  } catch (e) { toast("Error", e.message); }
}

// ── Global search ────────────────────────────────────────────────────────────
function globalFilter() {
  const q = document.getElementById("globalSearch").value.toLowerCase();
  document.querySelectorAll(".patient-card,.doctor-card,.medicine-card,.notify-card,.fleet-card")
    .forEach(c => c.style.display = c.textContent.toLowerCase().includes(q) ? "" : "none");
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function toast(title, body) {
  const box = document.getElementById("toastBox");
  const el  = document.createElement("div");
  el.style.cssText = "background:#fff;border:1px solid #e5e7eb;border-left:5px solid #1488d8;border-radius:14px;padding:14px 18px;box-shadow:0 10px 28px rgba(16,24,40,.12);min-width:260px;animation:slideIn .2s ease";
  el.innerHTML = `<b>${title}</b><br><small style="color:#667085">${body || ""}</small>`;
  box.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ── Keyboard shortcuts ────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  const lp = document.getElementById("loginPass");
  if (lp) lp.addEventListener("keydown", e => { if (e.key === "Enter") loginApp(); });
});

// ── Auto-refresh every 30s ────────────────────────────────────────────────────
setInterval(() => {
  if (jwtToken && !document.getElementById("app").classList.contains("hidden")) {
    loadData();
  }
}, 30000);
