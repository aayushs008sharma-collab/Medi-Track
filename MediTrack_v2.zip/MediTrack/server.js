/**
 * MediTrack Backend — v2.0
 * Enhanced with: JWT auth, Joi validation, real ETA calculation,
 * priority queue, rate limiting, helmet security, structured logging,
 * atomic DB writes, role-based access control, and full REST API.
 */

"use strict";

const express    = require("express");
const cors       = require("cors");
const helmet     = require("helmet");
const morgan     = require("morgan");
const rateLimit  = require("express-rate-limit");
const path       = require("path");

const logger          = require("./src/utils/logger");
const db              = require("./src/services/db");
const notifSvc        = require("./src/services/notifications");
const { errorHandler, notFound } = require("./src/middleware/errorHandler");

// ── Route modules ──────────────────────────────────────────────────────────
const authRoutes          = require("./src/routes/auth");
const patientRoutes       = require("./src/routes/patients");
const ambulanceRoutes     = require("./src/routes/ambulances");
const medicineRoutes      = require("./src/routes/medicines");
const doctorRoutes        = require("./src/routes/doctors");
const analyticsRoutes     = require("./src/routes/analytics");
const notificationRoutes  = require("./src/routes/notifications");

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Security headers ───────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: false, // disabled so the bundled frontend still works
  crossOriginEmbedderPolicy: false
}));

// ── CORS ───────────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.CORS_ORIGIN || "*",
  methods: ["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

// ── Body parsing ───────────────────────────────────────────────────────────
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

// ── HTTP request logging ───────────────────────────────────────────────────
app.use(morgan("combined", {
  stream: { write: msg => logger.http(msg.trim()) },
  skip: (req) => req.url === "/api/health"
}));

// ── Rate limiting ──────────────────────────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 500,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many requests, please try again later." }
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { success: false, message: "Too many login attempts." }
});

app.use("/api", globalLimiter);
app.use("/api/login", authLimiter);

// ── Static frontend ────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, "public")));

// ── Health check (no auth required) ───────────────────────────────────────
app.get("/api/health", (req, res) => {
  const data = db.read();
  res.json({
    status: "ok",
    uptime: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    queue: {
      waiting: data.patients.filter(p => p.status === "Waiting").length,
      serving: data.patients.filter(p => p.status === "Serving").length
    }
  });
});

// ── Backward-compat shim: old single-password login ───────────────────────
// The original frontend POSTs to /api/login with just { password, role }
// The new auth route handles this identically — no shim needed.

// ── Legacy /api/all-data endpoint (keeps old frontend working) ────────────
const { requireAuth } = require("./src/middleware/auth");
const queueSvc = require("./src/services/queue");

app.get("/api/all-data", requireAuth, (req, res) => {
  const data = db.read();
  const patients = queueSvc.recalculateWaitTimes(data.patients);
  const notifications = notifSvc.refreshTimestamps(data.notifications);

  res.json({
    patients,
    doctors:       data.doctors,
    medicines:     data.medicines,
    fleet:         data.fleet,
    notifications,
    analytics: {
      hours:  ["6AM","7AM","8AM","9AM","10AM","11AM","12PM","1PM","2PM","3PM","4PM","5PM"],
      flow:   [3, 5, 8, 12, 14, 11, 9, 10, 12, 9, 7, 6],
      weekly: [110, 145, 130, 190, 165, 120]
    }
  });
});

// Legacy compatibility aliases (old frontend calls)
app.post("/api/add-patient",        requireAuth, (req, res, next) => { req.url = "/patients"; patientRoutes(req, res, next); });
app.post("/api/update-patient",     requireAuth, (req, res, next) => {
  req.method = "PATCH";
  req.url = `/patients/${req.body.token}`;
  patientRoutes(req, res, next);
});
app.post("/api/call-next",          requireAuth, (req, res, next) => { req.url = "/queue/call-next"; patientRoutes(req, res, next); });
app.post("/api/dispatch-ambulance", requireAuth, (req, res, next) => { req.url = "/ambulances/dispatch"; ambulanceRoutes(req, res, next); });
app.post("/api/update-medicine",    requireAuth, (req, res, next) => {
  req.method = "PATCH";
  req.url = `/medicines/${req.body.id}`;
  medicineRoutes(req, res, next);
});
app.post("/api/read-notifications", requireAuth, (req, res, next) => { req.url = "/notifications/read"; notificationRoutes(req, res, next); });
app.post("/api/reset",              requireAuth, (req, res) => {
  db.reset();
  logger.warn("Database reset", { by: req.user?.role });
  res.json({ success: true, message: "Database reset to defaults" });
});

// ── API routes ─────────────────────────────────────────────────────────────
app.use("/api", authRoutes);
app.use("/api", patientRoutes);
app.use("/api", ambulanceRoutes);
app.use("/api", medicineRoutes);
app.use("/api", doctorRoutes);
app.use("/api", analyticsRoutes);
app.use("/api", notificationRoutes);

// ── SPA fallback — serve index.html for all non-API routes ─────────────────
app.get(/^(?!\/api).*/, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// ── Error handling ─────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Start ──────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  logger.info(`MediTrack v2.0 running`, {
    port: PORT,
    env: process.env.NODE_ENV || "development",
    url: `http://localhost:${PORT}`
  });
  logger.info("Default credentials", {
    Receptionist: "12345678",
    Doctor:        "doctor123",
    Pharmacist:    "pharm123",
    Admin:         "admin1234"
  });
});

module.exports = app;
