/**
 * Database Service
 * Handles JSON-file persistence with in-memory cache and queued writes
 * to prevent concurrent write corruption.
 */
const fs = require("fs");
const path = require("path");
const logger = require("../utils/logger");

const DB_PATH = path.join(__dirname, "../../data/db.json");
const DEFAULT_DB_PATH = path.join(__dirname, "../../data/default-db.json");

let _cache = null;
let _writeQueue = Promise.resolve();

/** Read from cache or disk */
function read() {
  if (_cache) return JSON.parse(JSON.stringify(_cache)); // deep clone
  try {
    const raw = fs.readFileSync(DB_PATH, "utf-8");
    _cache = JSON.parse(raw);
    return JSON.parse(JSON.stringify(_cache));
  } catch (err) {
    logger.error("DB read failed, restoring default", { error: err.message });
    const def = JSON.parse(fs.readFileSync(DEFAULT_DB_PATH, "utf-8"));
    _cache = def;
    return JSON.parse(JSON.stringify(_cache));
  }
}

/** Queue a write to prevent concurrent corruption */
function write(data) {
  _cache = JSON.parse(JSON.stringify(data));
  _writeQueue = _writeQueue.then(() =>
    new Promise((resolve, reject) => {
      const tmpPath = DB_PATH + ".tmp";
      const payload = JSON.stringify(data, null, 2);
      fs.writeFile(tmpPath, payload, "utf-8", (err) => {
        if (err) { logger.error("DB write (tmp) failed", { error: err.message }); return reject(err); }
        fs.rename(tmpPath, DB_PATH, (err2) => {
          if (err2) { logger.error("DB rename failed", { error: err2.message }); return reject(err2); }
          resolve();
        });
      });
    })
  );
  return _writeQueue;
}

/** Atomically update a subset of the DB */
function update(fn) {
  const db = read();
  const updated = fn(db);
  return write(updated !== undefined ? updated : db);
}

/** Hard reset to default */
function reset() {
  const def = JSON.parse(fs.readFileSync(DEFAULT_DB_PATH, "utf-8"));
  _cache = def;
  return write(def);
}

module.exports = { read, write, update, reset };
