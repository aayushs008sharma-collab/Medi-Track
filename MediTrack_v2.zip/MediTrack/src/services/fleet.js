/**
 * Fleet Service
 * Realistic ETA calculation for ambulances based on distance,
 * traffic factor, and case type urgency.
 */

// Average hospital-area speed in km/h by time of day
const BASE_SPEED_KMH = 40;

// Traffic multipliers by hour (0–23)
const TRAFFIC_FACTOR = [
  1.0, 1.0, 1.0, 1.0, 1.0, 1.0, // 00–05 (night, clear)
  1.2, 1.5, 1.8, 1.6, 1.3, 1.2, // 06–11 (morning rush)
  1.3, 1.2, 1.1, 1.1, 1.3, 1.7, // 12–17 (midday, evening rush)
  1.5, 1.3, 1.1, 1.0, 1.0, 1.0  // 18–23 (tapering off)
];

// Emergency vehicles get a siren discount
const SIREN_DISCOUNT = { Emergency: 0.6, Critical: 0.6, Cardiac: 0.65, Accident: 0.65, Normal: 1.0 };

/**
 * Calculate ETA in minutes for an ambulance given distance and case type.
 * @param {number} distanceKm
 * @param {string} caseType
 * @returns {{ etaMinutes: number, distanceKm: number, speedKmh: number }}
 */
function calculateAmbulanceETA(distanceKm, caseType = "Normal") {
  const hour = new Date().getHours();
  const traffic = TRAFFIC_FACTOR[hour] || 1.0;
  const sirenDiscount = SIREN_DISCOUNT[caseType] || 1.0;
  const effectiveSpeed = BASE_SPEED_KMH / traffic * (1 / sirenDiscount) * sirenDiscount;
  // Simpler: speed = BASE / traffic, then apply siren
  const speed = (BASE_SPEED_KMH / traffic) / sirenDiscount;
  const etaMinutes = Math.max(2, Math.ceil((distanceKm / speed) * 60));
  return {
    etaMinutes,
    etaLabel: `${etaMinutes} min`,
    distanceKm: parseFloat(distanceKm.toFixed(1)),
    distanceLabel: `${distanceKm.toFixed(1)} km`,
    speedKmh: Math.round(speed)
  };
}

/**
 * Pick the best available ambulance. Prefers Available, then nearest On Call.
 */
function selectBestAmbulance(fleet, preferUnit) {
  if (preferUnit) {
    const specific = fleet.find(a => a.unit === preferUnit);
    if (specific) return specific;
  }
  // Prefer Available units
  const available = fleet.filter(a => a.status === "Available");
  if (available.length) {
    // Pick nearest (smallest distance if parseable)
    return available.sort((a, b) => {
      const da = parseFloat(a.distance) || 99;
      const db = parseFloat(b.distance) || 99;
      return da - db;
    })[0];
  }
  // No available — return first non-busy
  return fleet.find(a => a.status !== "En Route") || null;
}

/**
 * Generate a random distance (1–10 km) for demo/simulation purposes.
 */
function randomDistance() {
  return parseFloat((Math.random() * 9 + 1).toFixed(1));
}

module.exports = { calculateAmbulanceETA, selectBestAmbulance, randomDistance };
