/**
 * Notification Service
 * Creates, timestamps, and trims notification records.
 */

const MAX_NOTIFICATIONS = 50;

const TYPE_LABELS = {
  Emergency: "🚨",
  Queue: "🏥",
  AI: "🤖",
  Medicine: "💊",
  Fleet: "🚑",
  System: "⚙️"
};

function formatTimeAgo(ts) {
  const diff = Date.now() - ts;
  if (diff < 60000) return "Just now";
  if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} hr ago`;
  return `${Math.floor(diff / 86400000)} day ago`;
}

function create(db, type, title, body) {
  const notification = {
    id: Date.now(),
    type,
    icon: TYPE_LABELS[type] || "📋",
    title,
    body,
    unread: true,
    time: "Just now",
    timestamp: Date.now()
  };

  db.notifications.unshift(notification);

  // Keep only latest N notifications
  if (db.notifications.length > MAX_NOTIFICATIONS) {
    db.notifications = db.notifications.slice(0, MAX_NOTIFICATIONS);
  }

  return notification;
}

function refreshTimestamps(notifications) {
  return notifications.map(n => ({
    ...n,
    time: n.timestamp ? formatTimeAgo(n.timestamp) : n.time
  }));
}

module.exports = { create, refreshTimestamps };
