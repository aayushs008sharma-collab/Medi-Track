/**
 * Queue Service
 * Handles all queue logic: priority ordering, ETA calculation,
 * doctor assignment, token generation, and queue metrics.
 */

// Priority weights — lower = higher priority
const PRIORITY_WEIGHT = { Emergency: 1, Urgent: 2, Normal: 3 };

// Average consultation times in minutes by department
const DEPT_CONSULT_TIMES = {
  "Emergency":        10,
  "Cardiology":       20,
  "General Medicine": 15,
  "Pediatrics":       15,
  "Orthopedics":      18,
  "Neurology":        22,
  "Dermatology":      12,
  "Ophthalmology":    12,
  "ENT":              12,
  "Gynecology":       18,
  "Psychiatry":       25,
  "Radiology":        20,
  "Oncology":         25,
};

const DEFAULT_CONSULT_TIME = 15;

/**
 * Generate next token in format MT-XXXX
 */
function nextToken(patients) {
  if (!patients.length) return "MT-1001";
  const max = patients.reduce((highest, p) => {
    const n = Number(String(p.token).replace(/[^0-9]/g, "")) || 1000;
    return Math.max(highest, n);
  }, 1000);
  return `MT-${max + 1}`;
}

/**
 * Sort patients by priority then arrival order.
 * Emergency → Urgent → Normal, ties broken by arrival position.
 */
function sortByPriority(patients) {
  return [...patients].sort((a, b) => {
    const pw = (PRIORITY_WEIGHT[a.priority] || 3) - (PRIORITY_WEIGHT[b.priority] || 3);
    if (pw !== 0) return pw;
    // Preserve relative order (stable sort by token number)
    const an = Number(String(a.token).replace(/[^0-9]/g, "")) || 0;
    const bn = Number(String(b.token).replace(/[^0-9]/g, "")) || 0;
    return an - bn;
  });
}

/**
 * Calculate ETA in minutes for a patient given the current queue snapshot.
 * Accounts for:
 *   - Patients ahead in the same department
 *   - Average consultation time per department
 *   - Number of serving patients consuming doctor time
 *   - Priority bumping
 */
function calculateETA(targetToken, allPatients) {
  const waiting = allPatients.filter(p => p.status === "Waiting");
  const serving = allPatients.filter(p => p.status === "Serving");
  const target = allPatients.find(p => p.token === targetToken);

  if (!target) return null;
  if (target.status === "Serving") return 0;
  if (target.status === "Done" || target.status === "Discharged") return -1;

  const sorted = sortByPriority(waiting);
  const positionInQueue = sorted.findIndex(p => p.token === targetToken);
  if (positionInQueue === -1) return null;

  const dept = target.dept;
  const consultTime = DEPT_CONSULT_TIMES[dept] || DEFAULT_CONSULT_TIME;

  // How many ahead in same dept
  const aheadSameDept = sorted
    .slice(0, positionInQueue)
    .filter(p => p.dept === dept).length;

  // Currently serving in this dept (time remaining estimate = half consult time)
  const servingSameDept = serving.filter(p => p.dept === dept).length;

  // Base wait: patients ahead (all depts, weighted by position) × average time
  // Plus time already being consumed by serving patients
  const aheadAll = positionInQueue; // total ahead in full sorted queue
  const avgConsultAll = waiting.slice(0, positionInQueue).reduce((sum, p) => {
    return sum + (DEPT_CONSULT_TIMES[p.dept] || DEFAULT_CONSULT_TIME);
  }, 0);

  // If a doctor is currently serving someone in this dept, they finish before taking next
  const servingOffset = servingSameDept > 0 ? Math.round(consultTime * 0.5) : 0;

  // ETA = sum of consult times of patients ahead in same dept + serving offset
  const deptWaitTime = aheadSameDept * consultTime + servingOffset;

  // Blend: 70% dept-specific, 30% global queue pressure
  const globalPressure = aheadAll > 0 ? Math.round((avgConsultAll / aheadAll) * 0.3) : 0;

  const eta = Math.max(1, deptWaitTime + globalPressure);

  return eta;
}

/**
 * Recalculate and update wait times for all waiting patients in the DB snapshot.
 * Returns modified patients array.
 */
function recalculateWaitTimes(patients) {
  return patients.map(p => {
    if (p.status === "Waiting") {
      const eta = calculateETA(p.token, patients);
      return { ...p, wait: eta !== null ? eta : p.wait };
    }
    return p;
  });
}

/**
 * Assign best available doctor for a department.
 * Prefers Available → On Round → Busy (fallback).
 */
function assignDoctor(doctors, dept) {
  const statusPriority = { Available: 1, "On Round": 2, Busy: 3 };
  const candidates = doctors
    .filter(d => d.department === dept)
    .sort((a, b) => (statusPriority[a.status] || 4) - (statusPriority[b.status] || 4));

  if (candidates.length) return candidates[0].name;

  // Fallback: any available doctor
  const anyAvailable = doctors.find(d => d.status === "Available");
  return anyAvailable ? anyAvailable.name : "Dr. On Duty";
}

/**
 * Get queue metrics snapshot.
 */
function getQueueMetrics(patients) {
  const byStatus = { Waiting: 0, Serving: 0, Done: 0 };
  const byPriority = { Emergency: 0, Urgent: 0, Normal: 0 };
  const byDept = {};

  patients.forEach(p => {
    byStatus[p.status] = (byStatus[p.status] || 0) + 1;
    byPriority[p.priority] = (byPriority[p.priority] || 0) + 1;
    byDept[p.dept] = (byDept[p.dept] || 0) + 1;
  });

  const waitingPatients = patients.filter(p => p.status === "Waiting");
  const avgWait = waitingPatients.length
    ? Math.round(waitingPatients.reduce((s, p) => s + (p.wait || 0), 0) / waitingPatients.length)
    : 0;

  return { byStatus, byPriority, byDept, avgWait, total: patients.length };
}

/**
 * Get next patient to serve (highest priority waiting patient).
 */
function getNextInQueue(patients) {
  const waiting = patients.filter(p => p.status === "Waiting");
  if (!waiting.length) return null;
  return sortByPriority(waiting)[0];
}

module.exports = {
  nextToken,
  sortByPriority,
  calculateETA,
  recalculateWaitTimes,
  assignDoctor,
  getQueueMetrics,
  getNextInQueue,
  PRIORITY_WEIGHT,
  DEPT_CONSULT_TIMES
};
