/**
 * Auth Middleware
 * JWT-based authentication. Tokens expire in 8 hours.
 * Roles: Receptionist, Doctor, Admin, Pharmacist
 */
const jwt = require("jsonwebtoken");
const logger = require("../utils/logger");

const JWT_SECRET = process.env.JWT_SECRET || "meditrack_dev_secret_change_in_prod_2024";
const TOKEN_EXPIRY = "8h";

// Role → allowed route prefixes (simple RBAC)
const ROLE_PERMISSIONS = {
  Admin:        ["*"],
  Doctor:       ["/api/patients", "/api/queue", "/api/analytics", "/api/all-data"],
  Receptionist: ["/api/patients", "/api/queue", "/api/ambulance", "/api/all-data", "/api/notifications"],
  Pharmacist:   ["/api/medicines", "/api/all-data", "/api/notifications"]
};

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
}

function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

/**
 * Middleware: require valid JWT. Attaches decoded payload to req.user.
 */
function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ success: false, message: "Authentication required" });
  }

  const token = header.slice(7);
  try {
    req.user = verifyToken(token);
    next();
  } catch (err) {
    const msg = err.name === "TokenExpiredError" ? "Token expired" : "Invalid token";
    logger.warn("Auth failure", { error: err.message, ip: req.ip });
    return res.status(401).json({ success: false, message: msg });
  }
}

/**
 * Middleware: require specific role(s).
 */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ success: false, message: "Not authenticated" });
    if (!roles.includes(req.user.role) && !roles.includes("*")) {
      logger.warn("Unauthorized role access", { role: req.user.role, required: roles, path: req.path });
      return res.status(403).json({ success: false, message: "Insufficient permissions" });
    }
    next();
  };
}

module.exports = { requireAuth, requireRole, signToken, verifyToken };
