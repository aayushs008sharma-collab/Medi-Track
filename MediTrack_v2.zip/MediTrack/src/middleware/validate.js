/**
 * Validation Middleware
 * Joi-based request body validation. Returns 422 with structured error on failure.
 */
const Joi = require("joi");

const DEPARTMENTS = [
  "Emergency", "Cardiology", "General Medicine", "Pediatrics",
  "Orthopedics", "Neurology", "Dermatology", "Ophthalmology",
  "ENT", "Gynecology", "Psychiatry", "Radiology", "Oncology"
];

const PRIORITIES = ["Emergency", "Urgent", "Normal"];
const PATIENT_STATUSES = ["Waiting", "Serving", "Done", "Discharged", "No Show"];
const MEDICINE_STATUSES = ["Upcoming", "Completed", "Missed", "Low Stock", "Out of Stock"];
const AMBULANCE_STATUSES = ["Available", "En Route", "On Call", "Maintenance"];

const schemas = {
  login: Joi.object({
    password: Joi.string().min(4).max(64).required(),
    role: Joi.string().valid("Receptionist", "Doctor", "Admin", "Pharmacist").default("Receptionist")
  }),

  addPatient: Joi.object({
    name:     Joi.string().min(2).max(100).trim().required(),
    age:      Joi.number().integer().min(0).max(120).required(),
    gender:   Joi.string().valid("Male", "Female", "Other").default("Male"),
    dept:     Joi.string().valid(...DEPARTMENTS).default("General Medicine"),
    symptoms: Joi.string().max(500).default("General consultation"),
    priority: Joi.string().valid(...PRIORITIES).default("Normal"),
    phone:    Joi.string().pattern(/^[0-9+\-\s()]{7,20}$/).optional().allow(""),
    address:  Joi.string().max(200).optional().allow("")
  }),

  updatePatient: Joi.object({
    token:  Joi.string().pattern(/^MT-\d+$/).required(),
    status: Joi.string().valid(...PATIENT_STATUSES).required(),
    notes:  Joi.string().max(500).optional().allow("")
  }),

  dispatchAmbulance: Joi.object({
    unit:     Joi.string().pattern(/^AMB-\d+$/).optional(),
    location: Joi.string().min(3).max(200).required(),
    caseType: Joi.string().max(50).default("Emergency"),
    distance: Joi.number().min(0.1).max(100).optional() // km, optional override
  }),

  updateMedicine: Joi.object({
    id:     Joi.alternatives().try(Joi.number(), Joi.string()).required(),
    status: Joi.string().valid(...MEDICINE_STATUSES).required(),
    notes:  Joi.string().max(200).optional().allow("")
  }),

  updateDoctor: Joi.object({
    name:   Joi.string().required(),
    status: Joi.string().valid("Available", "Busy", "On Round", "Off Duty").required()
  }),

  callNext: Joi.object({
    dept: Joi.string().valid(...DEPARTMENTS).optional()
  }),

  etaQuery: Joi.object({
    token: Joi.string().pattern(/^MT-\d+$/).required()
  }),

  updateAmbulance: Joi.object({
    unit:   Joi.string().pattern(/^AMB-\d+$/).required(),
    status: Joi.string().valid(...AMBULANCE_STATUSES).required()
  })
};

/**
 * Returns an Express middleware that validates req.body against the named schema.
 */
function validate(schemaName) {
  return (req, res, next) => {
    const schema = schemas[schemaName];
    if (!schema) return next();

    const { error, value } = schema.validate(req.body, {
      abortEarly: false,
      stripUnknown: true,
      convert: true
    });

    if (error) {
      const details = error.details.map(d => ({
        field: d.path.join("."),
        message: d.message.replace(/['"]/g, "")
      }));
      return res.status(422).json({
        success: false,
        message: "Validation failed",
        errors: details
      });
    }

    req.body = value;
    next();
  };
}

module.exports = { validate, DEPARTMENTS, PRIORITIES };
