/**
 * Doctors Routes
 *
 * GET   /api/doctors            — list all doctors
 * GET   /api/doctors/:name      — get one doctor + their patients
 * PATCH /api/doctors/:name      — update availability status
 */
const router = require("express").Router();
const db = require("../services/db");
const notifSvc = require("../services/notifications");
const { requireAuth, requireRole } = require("../middleware/auth");
const { validate } = require("../middleware/validate");
const logger = require("../utils/logger");

// GET /api/doctors
router.get("/doctors", requireAuth, (req, res) => {
  const data = db.read();
  const { status, dept } = req.query;

  let doctors = data.doctors;
  if (status) doctors = doctors.filter(d => d.status === status);
  if (dept)   doctors = doctors.filter(d => d.department === dept);

  // Attach patient counts
  const enriched = doctors.map(d => {
    const activePatients = data.patients.filter(
      p => p.doctor === d.name && ["Waiting", "Serving"].includes(p.status)
    );
    return {
      ...d,
      activePatientCount: activePatients.length,
      servingNow: activePatients.find(p => p.status === "Serving") || null
    };
  });

  res.json({ success: true, count: enriched.length, doctors: enriched });
});

// GET /api/doctors/:name
router.get("/doctors/:name", requireAuth, (req, res) => {
  const data = db.read();
  const name = decodeURIComponent(req.params.name);
  const doctor = data.doctors.find(d => d.name.toLowerCase() === name.toLowerCase());
  if (!doctor) return res.status(404).json({ success: false, message: "Doctor not found" });

  const patients = data.patients.filter(p => p.doctor === doctor.name);
  res.json({ success: true, doctor, patients });
});

// PATCH /api/doctors/:name  (was part of /api/update-patient implicitly)
router.patch("/doctors/:name", requireAuth, requireRole("Admin", "Doctor"), validate("updateDoctor"), (req, res) => {
  const data = db.read();
  const name = decodeURIComponent(req.params.name);
  const { status } = req.body;

  const idx = data.doctors.findIndex(d => d.name.toLowerCase() === name.toLowerCase());
  if (idx === -1) return res.status(404).json({ success: false, message: "Doctor not found" });

  const prev = data.doctors[idx];
  data.doctors[idx] = { ...prev, status, updatedAt: new Date().toISOString() };

  notifSvc.create(data, "Queue",
    `Dr. status update`,
    `${prev.name} is now ${status}.`
  );

  db.write(data);
  logger.info("Doctor status updated", { name: prev.name, from: prev.status, to: status });
  res.json({ success: true, doctor: data.doctors[idx] });
});

module.exports = router;
