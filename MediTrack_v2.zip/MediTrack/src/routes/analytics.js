/**
 * Analytics Routes
 *
 * GET /api/analytics          — full analytics snapshot
 * GET /api/analytics/summary  — quick KPIs
 * GET /api/analytics/dept     — per-department breakdown
 */
const router = require("express").Router();
const db = require("../services/db");
const queueSvc = require("../services/queue");
const { requireAuth } = require("../middleware/auth");

// Static hourly patient-flow baseline (can be replaced with real logged data)
const HOURLY_LABELS = ["6AM","7AM","8AM","9AM","10AM","11AM","12PM","1PM","2PM","3PM","4PM","5PM","6PM","7PM","8PM"];
const HOURLY_FLOW   = [3, 5, 8, 12, 14, 11, 9, 10, 12, 9, 7, 6, 8, 7, 4];
const WEEKLY_LABELS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const WEEKLY_FLOW   = [110, 145, 130, 190, 165, 120, 80];

function getDeptStats(patients) {
  const depts = {};
  patients.forEach(p => {
    if (!depts[p.dept]) {
      depts[p.dept] = { total: 0, waiting: 0, serving: 0, done: 0, emergency: 0, avgWait: 0, waitSum: 0 };
    }
    depts[p.dept].total++;
    if (p.status === "Waiting")  depts[p.dept].waiting++;
    if (p.status === "Serving")  depts[p.dept].serving++;
    if (p.status === "Done")     depts[p.dept].done++;
    if (p.priority === "Emergency") depts[p.dept].emergency++;
    if (p.status === "Waiting" && p.wait) {
      depts[p.dept].waitSum += p.wait;
    }
  });

  // Compute avgWait
  Object.keys(depts).forEach(d => {
    const w = depts[d].waiting;
    depts[d].avgWait = w > 0 ? Math.round(depts[d].waitSum / w) : 0;
    delete depts[d].waitSum;
  });

  return depts;
}

// GET /api/analytics
router.get("/analytics", requireAuth, (req, res) => {
  const data = db.read();
  const patients = data.patients;
  const metrics = queueSvc.getQueueMetrics(patients);
  const deptStats = getDeptStats(patients);

  // Doctor utilisation
  const doctorStats = data.doctors.map(d => {
    const assigned = patients.filter(p => p.doctor === d.name && p.status !== "Done").length;
    return { name: d.name, department: d.department, status: d.status, assignedPatients: assigned };
  });

  // Fleet summary
  const fleetSummary = {
    total:     data.fleet.length,
    available: data.fleet.filter(a => a.status === "Available").length,
    enRoute:   data.fleet.filter(a => a.status === "En Route").length,
    onCall:    data.fleet.filter(a => a.status === "On Call").length
  };

  // Medicine alerts
  const medicineAlerts = {
    lowStock:   data.medicines.filter(m => m.status === "Low Stock").length,
    outOfStock: data.medicines.filter(m => m.status === "Out of Stock").length,
    missed:     data.medicines.filter(m => m.status === "Missed").length,
    upcoming:   data.medicines.filter(m => m.status === "Upcoming").length
  };

  res.json({
    success: true,
    analytics: {
      queue: metrics,
      departments: deptStats,
      doctors: doctorStats,
      fleet: fleetSummary,
      medicines: medicineAlerts,
      charts: {
        hourly: { labels: HOURLY_LABELS, data: HOURLY_FLOW },
        weekly: { labels: WEEKLY_LABELS, data: WEEKLY_FLOW }
      },
      generatedAt: new Date().toISOString()
    }
  });
});

// GET /api/analytics/summary — lightweight KPIs for dashboard header
router.get("/analytics/summary", requireAuth, (req, res) => {
  const data = db.read();
  const waiting  = data.patients.filter(p => p.status === "Waiting").length;
  const serving  = data.patients.filter(p => p.status === "Serving").length;
  const emergency = data.patients.filter(p => p.priority === "Emergency" && p.status === "Waiting").length;
  const availDoctors = data.doctors.filter(d => d.status === "Available").length;
  const availAmb     = data.fleet.filter(a => a.status === "Available").length;
  const metrics  = queueSvc.getQueueMetrics(data.patients);

  res.json({
    success: true,
    summary: {
      waitingPatients:    waiting,
      servingPatients:    serving,
      emergencyPatients:  emergency,
      availableDoctors:   availDoctors,
      availableAmbulances: availAmb,
      avgWaitMinutes:     metrics.avgWait,
      totalPatients:      data.patients.length
    }
  });
});

// GET /api/analytics/dept
router.get("/analytics/dept", requireAuth, (req, res) => {
  const data = db.read();
  const deptStats = getDeptStats(data.patients);
  res.json({ success: true, departments: deptStats });
});

module.exports = router;
