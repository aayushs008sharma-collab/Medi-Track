/**
 * Notifications Routes
 *
 * GET   /api/notifications        — list (with refreshed timestamps)
 * POST  /api/notifications/read   — mark all as read
 * DELETE/api/notifications/:id    — delete one notification
 * DELETE/api/notifications        — clear all (Admin)
 */
const router = require("express").Router();
const db = require("../services/db");
const notifSvc = require("../services/notifications");
const { requireAuth, requireRole } = require("../middleware/auth");

// GET /api/notifications
router.get("/notifications", requireAuth, (req, res) => {
  const data = db.read();
  const notifications = notifSvc.refreshTimestamps(data.notifications);
  const unreadCount = notifications.filter(n => n.unread).length;
  res.json({ success: true, unreadCount, notifications });
});

// POST /api/notifications/read  (was /api/read-notifications)
router.post("/notifications/read", requireAuth, (req, res) => {
  const data = db.read();
  data.notifications.forEach(n => { n.unread = false; });
  db.write(data);
  res.json({ success: true });
});

// DELETE /api/notifications/:id
router.delete("/notifications/:id", requireAuth, (req, res) => {
  const data = db.read();
  const idx = data.notifications.findIndex(n => String(n.id) === String(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: "Notification not found" });
  const [removed] = data.notifications.splice(idx, 1);
  db.write(data);
  res.json({ success: true, removed });
});

// DELETE /api/notifications  (clear all)
router.delete("/notifications", requireAuth, requireRole("Admin"), (req, res) => {
  const data = db.read();
  data.notifications = [];
  db.write(data);
  res.json({ success: true, message: "All notifications cleared" });
});

module.exports = router;
