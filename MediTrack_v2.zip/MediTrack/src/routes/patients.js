/**
 * Patient & Queue Routes
 *
 * GET    /api/patients              — list all patients (filterable)
 * GET    /api/patients/:token       — get one patient + live ETA
 * POST   /api/patients              — register new patient
 * PATCH  /api/patients/:token       — update patient status/notes
 * DELETE /api/patients/:token       — remove patient (Admin only)
 *
 * POST   /api/queue/call-next       — call next patient (dept optional)
 * GET    /api/queue/eta/:token      — get ETA for a token
 * GET    /api/queue/metrics         — queue summary stats
 */
const router = require("express").Router();
const db = require("../services/db");
const queueSvc = require("../services/queue");
const notifSvc = require("../services/notifications");
const { requireAuth, requireRole } = require("../middleware/auth");
const { validate } = require("../middleware/validate");
const logger = require("../utils/logger");

/* ────────────────────────────── Patients ─────────────────────────────── */

// GET /api/patients
router.get("/patients", requireAuth, (req, res) => {
  const data = db.read();
  let patients = data.patients;

  // Optional filters
  const { status, dept, priority, search } = req.query;
  if (status)   patients = patients.filter(p => p.status === status);
  if (dept)     patients = patients.filter(p => p.dept === dept);
  if (priority) patients = patients.filter(p => p.priority === priority);
  if (search)   {
    const q = search.toLowerCase();
    patients = patients.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.token.toLowerCase().includes(q) ||
      (p.symptoms || "").toLowerCase().includes(q)
    );
  }

  // Refresh ETA for waiting patients
  const withETA = queueSvc.recalculateWaitTimes(patients);

  res.json({ success: true, count: withETA.length, patients: withETA });
});

// GET /api/patients/:token
router.get("/patients/:token", requireAuth, (req, res) => {
  const data = db.read();
  const patient = data.patients.find(p => p.token === req.params.token.toUpperCase());
  if (!patient) return res.status(404).json({ success: false, message: "Patient not found" });

  const eta = queueSvc.calculateETA(patient.token, data.patients);
  const position = queueSvc.sortByPriority(
    data.patients.filter(p => p.status === "Waiting")
  ).findIndex(p => p.token === patient.token);

  res.json({
    success: true,
    patient: { ...patient, wait: eta !== null ? eta : patient.wait },
    queuePosition: position >= 0 ? position + 1 : null,
    eta
  });
});

// POST /api/patients  (was /api/add-patient)
router.post("/patients", requireAuth, validate("addPatient"), (req, res) => {
  const data = db.read();
  const { name, age, gender, dept, symptoms, priority, phone, address } = req.body;

  const token = queueSvc.nextToken(data.patients);
  const doctor = queueSvc.assignDoctor(data.doctors, dept);

  const patient = {
    token,
    name,
    age,
    gender,
    dept,
    symptoms,
    priority,
    phone:   phone   || "",
    address: address || "",
    status:  "Waiting",
    doctor,
    wait:    priority === "Emergency" ? 2 : null,
    createdAt: new Date().toISOString()
  };

  // Emergency patients jump to front of waiting list
  if (priority === "Emergency") {
    data.patients.unshift(patient);
  } else {
    data.patients.push(patient);
  }

  // Calculate real ETA after insertion
  const eta = queueSvc.calculateETA(token, data.patients);
  patient.wait = eta !== null ? eta : patient.wait;

  notifSvc.create(data, priority === "Emergency" ? "Emergency" : "Queue",
    `New token: ${token}`,
    `${name} added to ${dept}. ETA: ${patient.wait} min.`
  );

  db.write(data);
  logger.info("Patient added", { token, name, dept, priority });

  res.status(201).json({ success: true, patient });
});

// PATCH /api/patients/:token  (was /api/update-patient)
router.patch("/patients/:token", requireAuth, validate("updatePatient"), (req, res, next) => {
  try {
    const data = db.read();
    const token = req.params.token.toUpperCase();
    const { status, notes } = req.body;

    const idx = data.patients.findIndex(p => p.token === token);
    if (idx === -1) return res.status(404).json({ success: false, message: "Patient not found" });

    const prev = data.patients[idx];
    data.patients[idx] = {
      ...prev,
      status,
      notes:     notes || prev.notes || "",
      updatedAt: new Date().toISOString()
    };

    // If marked Done/Discharged, recalculate ETAs for remaining queue
    if (["Done", "Discharged", "No Show"].includes(status)) {
      data.patients = queueSvc.recalculateWaitTimes(data.patients);
    }

    notifSvc.create(data, "Queue",
      `${token} → ${status}`,
      `${prev.name}'s status updated to ${status}.`
    );

    db.write(data);
    logger.info("Patient status updated", { token, status });

    res.json({ success: true, patient: data.patients[idx] });
  } catch (err) { next(err); }
});

// DELETE /api/patients/:token
router.delete("/patients/:token", requireAuth, requireRole("Admin"), (req, res) => {
  const data = db.read();
  const token = req.params.token.toUpperCase();
  const idx = data.patients.findIndex(p => p.token === token);
  if (idx === -1) return res.status(404).json({ success: false, message: "Patient not found" });

  const [removed] = data.patients.splice(idx, 1);
  data.patients = queueSvc.recalculateWaitTimes(data.patients);
  db.write(data);
  logger.info("Patient removed", { token });

  res.json({ success: true, removed });
});

/* ────────────────────────────── Queue Actions ────────────────────────── */

// POST /api/queue/call-next  (was /api/call-next)
router.post("/queue/call-next", requireAuth, validate("callNext"), (req, res) => {
  const data = db.read();
  const { dept } = req.body;

  let waiting = data.patients.filter(p => p.status === "Waiting");
  if (dept) waiting = waiting.filter(p => p.dept === dept);

  const next = queueSvc.getNextInQueue(waiting);
  if (!next) {
    return res.status(404).json({
      success: false,
      message: dept ? `No waiting patients in ${dept}` : "No waiting patients"
    });
  }

  const idx = data.patients.findIndex(p => p.token === next.token);
  data.patients[idx].status    = "Serving";
  data.patients[idx].servedAt  = new Date().toISOString();

  // Recalculate ETAs for remaining queue
  data.patients = queueSvc.recalculateWaitTimes(data.patients);

  notifSvc.create(data, "Queue",
    `Now calling ${next.token}`,
    `${next.name} → ${next.doctor}, ${next.dept}.`
  );

  db.write(data);
  logger.info("Called next patient", { token: next.token });

  res.json({ success: true, patient: data.patients[idx] });
});

// GET /api/queue/eta/:token
router.get("/queue/eta/:token", requireAuth, (req, res) => {
  const data = db.read();
  const token = req.params.token.toUpperCase();
  const patient = data.patients.find(p => p.token === token);

  if (!patient) return res.status(404).json({ success: false, message: "Patient not found" });

  const eta = queueSvc.calculateETA(token, data.patients);
  const sorted = queueSvc.sortByPriority(data.patients.filter(p => p.status === "Waiting"));
  const position = sorted.findIndex(p => p.token === token);

  res.json({
    success: true,
    token,
    etaMinutes: eta,
    etaLabel:   eta !== null ? (eta <= 0 ? "Being seen now" : `~${eta} min`) : "N/A",
    queuePosition: position >= 0 ? position + 1 : null,
    status: patient.status
  });
});

// GET /api/queue/metrics
router.get("/queue/metrics", requireAuth, (req, res) => {
  const data = db.read();
  const metrics = queueSvc.getQueueMetrics(data.patients);
  res.json({ success: true, metrics });
});

module.exports = router;
