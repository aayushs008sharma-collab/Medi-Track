/**
 * Auth Routes
 * POST /api/login       — password + role → JWT
 * POST /api/refresh     — renew token
 * GET  /api/me          — get current user info
 */
const router = require("express").Router();
const { signToken, requireAuth } = require("../middleware/auth");
const { validate } = require("../middleware/validate");
const logger = require("../utils/logger");

// Single shared password (production would use a users table)
const PASSWORDS = {
  Admin:        process.env.ADMIN_PASSWORD  || "admin1234",
  Doctor:       process.env.DOCTOR_PASSWORD || "doctor123",
  Receptionist: process.env.RECEP_PASSWORD  || "12345678",
  Pharmacist:   process.env.PHARM_PASSWORD  || "pharm123"
};

router.post("/login", validate("login"), (req, res) => {
  const { password, role } = req.body;

  const expectedPassword = PASSWORDS[role];

  if (!expectedPassword || password !== expectedPassword) {
    logger.warn("Failed login attempt", { role, ip: req.ip });
    return res.status(401).json({ success: false, message: "Invalid credentials" });
  }

  const token = signToken({ role, loginAt: Date.now() });
  logger.info("Login success", { role });

  res.json({
    success: true,
    token,
    role,
    expiresIn: "8h"
  });
});

router.post("/refresh", requireAuth, (req, res) => {
  const token = signToken({ role: req.user.role, loginAt: req.user.loginAt });
  res.json({ success: true, token });
});

router.get("/me", requireAuth, (req, res) => {
  res.json({ success: true, user: req.user });
});

module.exports = router;
