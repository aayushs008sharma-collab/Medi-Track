/**
 * Medicine / Pharmacy Routes
 *
 * GET   /api/medicines              — list all medicines (filterable)
 * GET   /api/medicines/:id          — get one medicine
 * POST  /api/medicines              — add medicine record
 * PATCH /api/medicines/:id          — update status / stock
 * DELETE/api/medicines/:id          — remove (Admin/Pharmacist)
 */
const router = require("express").Router();
const db = require("../services/db");
const notifSvc = require("../services/notifications");
const { requireAuth, requireRole } = require("../middleware/auth");
const { validate } = require("../middleware/validate");
const logger = require("../utils/logger");

// GET /api/medicines
router.get("/medicines", requireAuth, (req, res) => {
  const data = db.read();
  let medicines = data.medicines;

  const { status, search } = req.query;
  if (status) medicines = medicines.filter(m => m.status === status);
  if (search) {
    const q = search.toLowerCase();
    medicines = medicines.filter(m =>
      m.name.toLowerCase().includes(q) ||
      (m.patient || "").toLowerCase().includes(q)
    );
  }

  // Attach low-stock flag
  medicines = medicines.map(m => ({
    ...m,
    lowStock: m.status === "Low Stock" || m.status === "Out of Stock"
  }));

  res.json({ success: true, count: medicines.length, medicines });
});

// GET /api/medicines/:id
router.get("/medicines/:id", requireAuth, (req, res) => {
  const data = db.read();
  const medicine = data.medicines.find(m => String(m.id) === String(req.params.id));
  if (!medicine) return res.status(404).json({ success: false, message: "Medicine not found" });
  res.json({ success: true, medicine });
});

// POST /api/medicines
router.post("/medicines", requireAuth, requireRole("Admin", "Pharmacist"), (req, res) => {
  const data = db.read();
  const { name, patient, time, stock, status } = req.body;

  if (!name) return res.status(422).json({ success: false, message: "Medicine name required" });

  const medicine = {
    id:        Date.now(),
    name,
    patient:   patient || "",
    time:      time    || new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
    stock:     stock   || "N/A",
    status:    status  || "Upcoming",
    createdAt: new Date().toISOString()
  };

  data.medicines.push(medicine);

  notifSvc.create(data, "Medicine",
    `Medicine added: ${name}`,
    `Assigned to ${patient || "unassigned"}. Status: ${medicine.status}.`
  );

  db.write(data);
  logger.info("Medicine added", { id: medicine.id, name });
  res.status(201).json({ success: true, medicine });
});

// PATCH /api/medicines/:id  (was /api/update-medicine)
router.patch("/medicines/:id", requireAuth, validate("updateMedicine"), (req, res) => {
  const data = db.read();
  const { status, notes } = req.body;

  const idx = data.medicines.findIndex(m => String(m.id) === String(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: "Medicine not found" });

  const prev = data.medicines[idx];
  data.medicines[idx] = {
    ...prev,
    status,
    notes:     notes || prev.notes || "",
    updatedAt: new Date().toISOString()
  };

  notifSvc.create(data, "Medicine",
    `${prev.name} → ${status}`,
    `${prev.patient || "Stock"} medicine marked ${status}.`
  );

  db.write(data);
  logger.info("Medicine updated", { id: req.params.id, status });
  res.json({ success: true, medicine: data.medicines[idx] });
});

// DELETE /api/medicines/:id
router.delete("/medicines/:id", requireAuth, requireRole("Admin", "Pharmacist"), (req, res) => {
  const data = db.read();
  const idx = data.medicines.findIndex(m => String(m.id) === String(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: "Medicine not found" });

  const [removed] = data.medicines.splice(idx, 1);
  db.write(data);
  logger.info("Medicine removed", { id: req.params.id });
  res.json({ success: true, removed });
});

module.exports = router;
