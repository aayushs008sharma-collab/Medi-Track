/**
 * Ambulance / Fleet Routes
 *
 * GET   /api/ambulances             — list fleet
 * POST  /api/ambulances/dispatch    — dispatch (was /api/dispatch-ambulance)
 * PATCH /api/ambulances/:unit       — update status (return, maintenance)
 */
const router = require("express").Router();
const db = require("../services/db");
const fleetSvc = require("../services/fleet");
const notifSvc = require("../services/notifications");
const { requireAuth } = require("../middleware/auth");
const { validate } = require("../middleware/validate");
const logger = require("../utils/logger");

// GET /api/ambulances
router.get("/ambulances", requireAuth, (req, res) => {
  const data = db.read();
  res.json({ success: true, fleet: data.fleet });
});

// POST /api/ambulances/dispatch
router.post("/ambulances/dispatch", requireAuth, validate("dispatchAmbulance"), (req, res) => {
  const data = db.read();
  const { unit, location, caseType, distance: distanceOverride } = req.body;

  const ambulance = fleetSvc.selectBestAmbulance(data.fleet, unit);
  if (!ambulance) {
    return res.status(503).json({ success: false, message: "No ambulances available" });
  }

  if (ambulance.status === "En Route") {
    return res.status(409).json({
      success: false,
      message: `${ambulance.unit} is already en route. Choose another unit.`
    });
  }

  const distanceKm = distanceOverride || fleetSvc.randomDistance();
  const { etaMinutes, etaLabel, distanceLabel, speedKmh } = fleetSvc.calculateAmbulanceETA(distanceKm, caseType);

  ambulance.status       = "En Route";
  ambulance.distance     = distanceLabel;
  ambulance.eta          = etaLabel;
  ambulance.etaMinutes   = etaMinutes;
  ambulance.location     = location;
  ambulance.caseType     = caseType;
  ambulance.dispatchedAt = new Date().toISOString();

  notifSvc.create(data, "Fleet",
    `${ambulance.unit} dispatched`,
    `${caseType} at ${location}. ETA: ${etaLabel} (${distanceLabel}).`
  );

  db.write(data);
  logger.info("Ambulance dispatched", { unit: ambulance.unit, location, caseType, etaMinutes });

  res.json({ success: true, ambulance });
});

// PATCH /api/ambulances/:unit
router.patch("/ambulances/:unit", requireAuth, validate("updateAmbulance"), (req, res) => {
  const data = db.read();
  const unitId = req.params.unit.toUpperCase();
  const { status } = req.body;

  const ambulance = data.fleet.find(a => a.unit === unitId);
  if (!ambulance) return res.status(404).json({ success: false, message: "Ambulance not found" });

  const prev = ambulance.status;
  ambulance.status = status;
  if (status === "Available") {
    ambulance.location  = "";
    ambulance.caseType  = "";
    ambulance.returnedAt = new Date().toISOString();
  }

  notifSvc.create(data, "Fleet",
    `${unitId} status: ${prev} → ${status}`,
    `${ambulance.driver} unit updated.`
  );

  db.write(data);
  logger.info("Ambulance status updated", { unit: unitId, from: prev, to: status });

  res.json({ success: true, ambulance });
});

module.exports = router;
